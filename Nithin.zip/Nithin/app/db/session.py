import logging
from typing import Generator
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker, Session
from app.core.config import settings
from app.db.base import Base
# Ensure all models are imported so metadata is populated
import app.models  # noqa: F401

logger = logging.getLogger("rbac.db")
logging.basicConfig(level=logging.INFO)

db_url = settings.sync_database_url
connect_args = {}

if db_url.startswith("sqlite"):
    connect_args["check_same_thread"] = False

try:
    engine = create_engine(
        db_url,
        pool_pre_ping=True,
        pool_recycle=3600,
        echo=False,
        connect_args=connect_args
    )
    # Quick probe test
    with engine.connect() as conn:
        conn.execute(text("SELECT 1"))
    logger.info(f"Database connected successfully to: {db_url.split('@')[-1] if '@' in db_url else db_url}")
except Exception as e:
    if settings.USE_SQLITE_FALLBACK_ON_ERROR and not db_url.startswith("sqlite"):
        logger.warning(
            f"Could not connect to MySQL ({e}). "
            "Falling back to local SQLite database ('sqlite:///./rbac.db') for seamless testing. "
            "To connect to MySQL, ensure MySQL is running and update .env settings."
        )
        fallback_url = "sqlite:///./rbac.db"
        engine = create_engine(
            fallback_url,
            pool_pre_ping=True,
            connect_args={"check_same_thread": False}
        )
    else:
        raise e

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def get_db() -> Generator[Session, None, None]:
    """FastAPI Dependency for database session management."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
