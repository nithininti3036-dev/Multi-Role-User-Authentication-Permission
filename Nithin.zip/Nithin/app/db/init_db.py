import logging
from sqlalchemy.orm import Session
from app.db.base import Base
from app.db.session import engine, SessionLocal
from app.models.permission import Permission
from app.models.role import Role
from app.models.user import User
from app.core.security import get_password_hash
from app.core.config import settings

logger = logging.getLogger("rbac.init_db")


DEFAULT_PERMISSIONS = [
    # Wildcard
    {"name": "*:*", "resource": "all", "action": "all", "description": "Full wildcard access to every resource"},
    
    # User permissions
    {"name": "user:create", "resource": "user", "action": "create", "description": "Create new users"},
    {"name": "user:read", "resource": "user", "action": "read", "description": "View user profiles and list"},
    {"name": "user:update", "resource": "user", "action": "update", "description": "Modify user information"},
    {"name": "user:delete", "resource": "user", "action": "delete", "description": "Delete or deactivate users"},
    {"name": "user:manage", "resource": "user", "action": "manage", "description": "Full management of users"},
    
    # Role permissions
    {"name": "role:create", "resource": "role", "action": "create", "description": "Create custom roles"},
    {"name": "role:read", "resource": "role", "action": "read", "description": "View roles and their permissions"},
    {"name": "role:update", "resource": "role", "action": "update", "description": "Modify role details and assign permissions"},
    {"name": "role:delete", "resource": "role", "action": "delete", "description": "Delete custom roles"},
    {"name": "role:assign", "resource": "role", "action": "assign", "description": "Assign or unassign roles to users"},
    
    # Permission permissions
    {"name": "permission:read", "resource": "permission", "action": "read", "description": "View available system permissions"},
    {"name": "permission:create", "resource": "permission", "action": "create", "description": "Create new custom permissions"},
    
    # Content permissions
    {"name": "content:create", "resource": "content", "action": "create", "description": "Create new articles or content"},
    {"name": "content:read", "resource": "content", "action": "read", "description": "View content items"},
    {"name": "content:update", "resource": "content", "action": "update", "description": "Edit existing content"},
    {"name": "content:delete", "resource": "content", "action": "delete", "description": "Remove content items"},
    
    # Report permissions
    {"name": "report:create", "resource": "report", "action": "create", "description": "Generate new analytical reports"},
    {"name": "report:read", "resource": "report", "action": "read", "description": "Access business reports"},
    {"name": "report:export", "resource": "report", "action": "export", "description": "Export reports to CSV/PDF"},
    {"name": "report:delete", "resource": "report", "action": "delete", "description": "Delete reports"},
    
    # Audit & System
    {"name": "audit:read", "resource": "audit", "action": "read", "description": "View system audit security logs"},
    {"name": "system:admin", "resource": "system", "action": "admin", "description": "Access system maintenance endpoints"},
]


def init_db(db: Session) -> None:
    """Create tables and seed initial permissions, roles, and default users."""
    logger.info("Creating database tables if not exist...")
    Base.metadata.create_all(bind=engine)

    # 1. Seed Permissions
    permission_map = {}
    for perm_data in DEFAULT_PERMISSIONS:
        perm = db.query(Permission).filter_by(name=perm_data["name"]).first()
        if not perm:
            perm = Permission(**perm_data)
            db.add(perm)
            db.flush()
            logger.info(f"Seeded permission: {perm.name}")
        permission_map[perm.name] = perm

    # 2. Seed Roles
    # SuperAdmin: all permissions + wildcard
    superadmin_role = db.query(Role).filter_by(name="SuperAdmin").first()
    if not superadmin_role:
        superadmin_role = Role(
            name="SuperAdmin",
            description="Full unrestricted system owner access",
            is_system=True,
            permissions=list(permission_map.values())
        )
        db.add(superadmin_role)
        logger.info("Seeded role: SuperAdmin")
    else:
        # Ensure SuperAdmin has all permissions
        superadmin_role.permissions = list(permission_map.values())

    # Admin: all CRUD except wildcard
    admin_perms = [p for name, p in permission_map.items() if name != "*:*"]
    admin_role = db.query(Role).filter_by(name="Admin").first()
    if not admin_role:
        admin_role = Role(
            name="Admin",
            description="System administrator with user, role, and resource management rights",
            is_system=True,
            permissions=admin_perms
        )
        db.add(admin_role)
        logger.info("Seeded role: Admin")

    # Manager: user:read, content:*, report:*
    manager_perms = [
        permission_map[name] for name in [
            "user:read", "content:create", "content:read", "content:update",
            "report:create", "report:read", "report:export"
        ] if name in permission_map
    ]
    manager_role = db.query(Role).filter_by(name="Manager").first()
    if not manager_role:
        manager_role = Role(
            name="Manager",
            description="Department manager with content & reporting permissions",
            is_system=True,
            permissions=manager_perms
        )
        db.add(manager_role)
        logger.info("Seeded role: Manager")

    # User: standard member
    user_perms = [
        permission_map[name] for name in [
            "content:read", "report:read"
        ] if name in permission_map
    ]
    user_role = db.query(Role).filter_by(name="User").first()
    if not user_role:
        user_role = Role(
            name="User",
            description="Standard registered member with default read access",
            is_system=True,
            permissions=user_perms
        )
        db.add(user_role)
        logger.info("Seeded role: User")

    db.flush()

    # 3. Seed Default SuperAdmin User
    superadmin_user = db.query(User).filter_by(email=settings.FIRST_SUPERADMIN_EMAIL).first()
    if not superadmin_user:
        superadmin_user = User(
            username=settings.FIRST_SUPERADMIN_USERNAME,
            email=settings.FIRST_SUPERADMIN_EMAIL,
            hashed_password=get_password_hash(settings.FIRST_SUPERADMIN_PASSWORD),
            full_name="Master Administrator",
            is_active=True,
            is_verified=True,
            roles=[superadmin_role, admin_role]
        )
        db.add(superadmin_user)
        logger.info(f"Seeded default SuperAdmin: {settings.FIRST_SUPERADMIN_EMAIL}")

    # 4. Seed a Demo Standard User
    demo_user = db.query(User).filter_by(email="user@example.com").first()
    if not demo_user:
        demo_user = User(
            username="johndoe",
            email="user@example.com",
            hashed_password=get_password_hash("User@123456"),
            full_name="John Doe",
            is_active=True,
            is_verified=True,
            roles=[user_role]
        )
        db.add(demo_user)
        logger.info("Seeded demo user: user@example.com")

    # 5. Seed a Demo Manager User
    demo_manager = db.query(User).filter_by(email="manager@example.com").first()
    if not demo_manager:
        demo_manager = User(
            username="sarah_manager",
            email="manager@example.com",
            hashed_password=get_password_hash("Manager@123456"),
            full_name="Sarah Jenkins",
            is_active=True,
            is_verified=True,
            roles=[manager_role]
        )
        db.add(demo_manager)
        logger.info("Seeded demo manager: manager@example.com")

    db.commit()
    logger.info("Database initialization and seed completed successfully!")


if __name__ == "__main__":
    db = SessionLocal()
    try:
        init_db(db)
    finally:
        db.close()
