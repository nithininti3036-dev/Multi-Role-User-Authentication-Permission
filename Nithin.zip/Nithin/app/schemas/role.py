from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, ConfigDict, Field
from app.schemas.permission import PermissionResponse


class RoleBase(BaseModel):
    name: str = Field(..., min_length=2, max_length=50, description="Role name, e.g. 'Editor', 'Manager'")
    description: Optional[str] = None


class RoleCreate(RoleBase):
    permission_ids: Optional[List[int]] = Field(default_factory=list, description="List of permission IDs to attach")


class RoleUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=2, max_length=50)
    description: Optional[str] = None
    permission_ids: Optional[List[int]] = None


class RolePermissionAssignRequest(BaseModel):
    permission_ids: List[int] = Field(..., description="Array of permission IDs to grant this role")


class RoleResponse(RoleBase):
    id: int
    is_system: bool
    created_at: datetime
    permissions: List[PermissionResponse] = []

    model_config = ConfigDict(from_attributes=True)
