from datetime import datetime
from typing import Optional
from pydantic import BaseModel, ConfigDict, Field


class PermissionBase(BaseModel):
    name: str = Field(..., description="Unique permission key, e.g. 'user:create' or 'report:read'")
    resource: str = Field(..., description="Target resource, e.g. 'user', 'role', 'content'")
    action: str = Field(..., description="Action, e.g. 'create', 'read', 'update', 'delete'")
    description: Optional[str] = None


class PermissionCreate(PermissionBase):
    pass


class PermissionResponse(PermissionBase):
    id: int
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)
