from typing import List, Optional
from sqlalchemy.orm import Session
from fastapi import HTTPException, status

from app.models.user import User
from app.models.role import Role
from app.schemas.user import UserCreate, UserUpdate
from app.core.security import get_password_hash
from app.services.audit_service import AuditService


class UserService:
    @staticmethod
    def get_users(
        db: Session,
        skip: int = 0,
        limit: int = 100,
        role_name: Optional[str] = None,
        is_active: Optional[bool] = None
    ) -> List[User]:
        query = db.query(User)
        if is_active is not None:
            query = query.filter(User.is_active == is_active)
        if role_name:
            query = query.join(User.roles).filter(Role.name == role_name)
        return query.order_by(User.id.asc()).offset(skip).limit(limit).all()

    @staticmethod
    def get_user_by_id(db: Session, user_id: int) -> User:
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
        return user

    @staticmethod
    def create_user(db: Session, user_in: UserCreate, current_user: Optional[User] = None) -> User:
        if db.query(User).filter(User.username == user_in.username).first():
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Username already exists")
        if db.query(User).filter(User.email == user_in.email).first():
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Email already exists")

        roles = []
        if user_in.role_ids:
            roles = db.query(Role).filter(Role.id.in_(user_in.role_ids)).all()
        else:
            default_role = db.query(Role).filter_by(name="User").first()
            if default_role:
                roles = [default_role]

        new_user = User(
            username=user_in.username,
            email=user_in.email,
            hashed_password=get_password_hash(user_in.password),
            full_name=user_in.full_name,
            is_active=user_in.is_active,
            roles=roles
        )
        db.add(new_user)
        db.commit()
        db.refresh(new_user)

        AuditService.log_event(
            db=db,
            action="USER_CREATED_BY_ADMIN",
            resource="user",
            user_id=current_user.id if current_user else None,
            resource_id=str(new_user.id),
            details={"created_user": new_user.username, "roles": new_user.role_names}
        )
        return new_user

    @staticmethod
    def update_user(
        db: Session,
        user_id: int,
        user_in: UserUpdate,
        current_user: Optional[User] = None
    ) -> User:
        user = UserService.get_user_by_id(db, user_id)

        if user_in.email and user_in.email != user.email:
            existing = db.query(User).filter(User.email == user_in.email).first()
            if existing:
                raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Email already taken")
            user.email = user_in.email

        if user_in.full_name is not None:
            user.full_name = user_in.full_name

        if user_in.is_active is not None:
            # Prevent deactivating the last SuperAdmin
            if not user_in.is_active and user.is_superadmin:
                superadmins = db.query(User).join(User.roles).filter(Role.name == "SuperAdmin", User.is_active == True).count()
                if superadmins <= 1:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Cannot deactivate the only active SuperAdmin account"
                    )
            user.is_active = user_in.is_active

        db.commit()
        db.refresh(user)

        AuditService.log_event(
            db=db,
            action="USER_UPDATED",
            resource="user",
            user_id=current_user.id if current_user else None,
            resource_id=str(user.id),
            details={"updated_username": user.username}
        )
        return user

    @staticmethod
    def update_user_status(
        db: Session,
        user_id: int,
        is_active: bool,
        current_user: Optional[User] = None
    ) -> User:
        user = UserService.get_user_by_id(db, user_id)
        if not is_active and user.is_superadmin:
            superadmins = db.query(User).join(User.roles).filter(Role.name == "SuperAdmin", User.is_active == True).count()
            if superadmins <= 1:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Cannot deactivate the only active SuperAdmin account"
                )

        user.is_active = is_active
        db.commit()
        db.refresh(user)

        AuditService.log_event(
            db=db,
            action="USER_STATUS_CHANGED",
            resource="user",
            user_id=current_user.id if current_user else None,
            resource_id=str(user.id),
            details={"is_active": is_active}
        )
        return user

    @staticmethod
    def assign_roles_to_user(
        db: Session,
        user_id: int,
        role_ids: List[int],
        current_user: Optional[User] = None
    ) -> User:
        user = UserService.get_user_by_id(db, user_id)
        roles = db.query(Role).filter(Role.id.in_(role_ids)).all()
        user.roles = roles
        db.commit()
        db.refresh(user)

        AuditService.log_event(
            db=db,
            action="USER_ROLES_ASSIGNED",
            resource="user",
            user_id=current_user.id if current_user else None,
            resource_id=str(user.id),
            details={"assigned_roles": user.role_names}
        )
        return user

    @staticmethod
    def remove_role_from_user(
        db: Session,
        user_id: int,
        role_id: int,
        current_user: Optional[User] = None
    ) -> User:
        user = UserService.get_user_by_id(db, user_id)
        role = db.query(Role).filter(Role.id == role_id).first()
        if not role:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Role not found")

        # Check if attempting to remove last SuperAdmin
        if role.name == "SuperAdmin":
            superadmins = db.query(User).join(User.roles).filter(Role.name == "SuperAdmin", User.is_active == True).count()
            if superadmins <= 1:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Cannot remove SuperAdmin role from the last active SuperAdmin"
                )

        if role in user.roles:
            user.roles.remove(role)
            db.commit()
            db.refresh(user)

        AuditService.log_event(
            db=db,
            action="USER_ROLE_REMOVED",
            resource="user",
            user_id=current_user.id if current_user else None,
            resource_id=str(user.id),
            details={"removed_role": role.name}
        )
        return user
