from datetime import timedelta
from typing import Optional, Tuple
from sqlalchemy.orm import Session
from fastapi import HTTPException, status

from app.models.user import User
from app.models.role import Role
from app.schemas.auth import RegisterRequest, LoginRequest
from app.core.security import (
    verify_password,
    get_password_hash,
    create_access_token,
    create_refresh_token,
    decode_token
)
from app.core.config import settings
from app.services.audit_service import AuditService


class AuthService:
    @staticmethod
    def authenticate_user(
        db: Session,
        credentials: LoginRequest,
        ip_address: Optional[str] = None
    ) -> Tuple[User, str, str]:
        """Authenticate user by username or email and return tokens."""
        query = db.query(User).filter(
            (User.username == credentials.username_or_email) |
            (User.email == credentials.username_or_email)
        )
        user = query.first()

        if not user or not verify_password(credentials.password, user.hashed_password):
            AuditService.log_event(
                db=db,
                action="LOGIN_FAILED",
                resource="auth",
                user_id=user.id if user else None,
                details={"identifier": credentials.username_or_email},
                ip_address=ip_address
            )
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Incorrect username/email or password",
                headers={"WWW-Authenticate": "Bearer"},
            )

        if not user.is_active:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Account has been deactivated. Please contact an administrator."
            )

        # Generate tokens
        access_token = create_access_token(
            subject=user.id,
            claims={
                "username": user.username,
                "email": user.email,
                "roles": user.role_names
            }
        )
        refresh_token = create_refresh_token(subject=user.id)

        AuditService.log_event(
            db=db,
            action="LOGIN_SUCCESS",
            resource="auth",
            user_id=user.id,
            details={"roles": user.role_names},
            ip_address=ip_address
        )

        return user, access_token, refresh_token

    @staticmethod
    def register_user(
        db: Session,
        user_in: RegisterRequest,
        ip_address: Optional[str] = None
    ) -> User:
        """Register a new user and assign default 'User' role."""
        # Check uniqueness
        if db.query(User).filter(User.username == user_in.username).first():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Username already registered"
            )
        if db.query(User).filter(User.email == user_in.email).first():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Email address already registered"
            )

        # Default role
        default_role = db.query(Role).filter_by(name="User").first()
        roles = [default_role] if default_role else []

        new_user = User(
            username=user_in.username,
            email=user_in.email,
            hashed_password=get_password_hash(user_in.password),
            full_name=user_in.full_name,
            is_active=True,
            is_verified=False,
            roles=roles
        )
        db.add(new_user)
        db.commit()
        db.refresh(new_user)

        AuditService.log_event(
            db=db,
            action="USER_REGISTERED",
            resource="user",
            user_id=new_user.id,
            resource_id=str(new_user.id),
            details={"email": new_user.email, "roles": new_user.role_names},
            ip_address=ip_address
        )

        return new_user

    @staticmethod
    def refresh_access_token(
        db: Session,
        refresh_token: str
    ) -> Tuple[str, str]:
        """Validate refresh token and issue a fresh pair of tokens."""
        payload = decode_token(refresh_token)
        if not payload or payload.get("type") != "refresh":
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid or expired refresh token",
                headers={"WWW-Authenticate": "Bearer"},
            )

        user_id = payload.get("sub")
        if not user_id:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token payload"
            )

        user = db.query(User).filter(User.id == int(user_id)).first()
        if not user or not user.is_active:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="User not found or deactivated"
            )

        new_access_token = create_access_token(
            subject=user.id,
            claims={
                "username": user.username,
                "email": user.email,
                "roles": user.role_names
            }
        )
        new_refresh_token = create_refresh_token(subject=user.id)
        return new_access_token, new_refresh_token

    @staticmethod
    def change_password(
        db: Session,
        user: User,
        old_password: str,
        new_password: str
    ) -> None:
        """Allow user to change their password."""
        if not verify_password(old_password, user.hashed_password):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Current password does not match"
            )

        user.hashed_password = get_password_hash(new_password)
        db.commit()

        AuditService.log_event(
            db=db,
            action="PASSWORD_CHANGED",
            resource="user",
            user_id=user.id,
            resource_id=str(user.id)
        )
