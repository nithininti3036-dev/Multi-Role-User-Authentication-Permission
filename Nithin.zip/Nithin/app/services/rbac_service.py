from typing import List, Optional
from sqlalchemy.orm import Session
from fastapi import HTTPException, status

from app.models.role import Role
from app.models.permission import Permission
from app.models.user import User
from app.schemas.role import RoleCreate, RoleUpdate
from app.schemas.permission import PermissionCreate
from app.services.audit_service import AuditService


class RBACService:
    @staticmethod
    def get_roles(db: Session, skip: int = 0, limit: int = 100) -> List[Role]:
        return db.query(Role).offset(skip).limit(limit).all()

    @staticmethod
    def get_role_by_id(db: Session, role_id: int) -> Role:
        role = db.query(Role).filter(Role.id == role_id).first()
        if not role:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Role not found")
        return role

    @staticmethod
    def create_role(db: Session, role_in: RoleCreate, current_user: Optional[User] = None) -> Role:
        existing = db.query(Role).filter(Role.name == role_in.name).first()
        if existing:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Role with name '{role_in.name}' already exists"
            )

        permissions = []
        if role_in.permission_ids:
            permissions = db.query(Permission).filter(Permission.id.in_(role_in.permission_ids)).all()

        new_role = Role(
            name=role_in.name,
            description=role_in.description,
            is_system=False,
            permissions=permissions
        )
        db.add(new_role)
        db.commit()
        db.refresh(new_role)

        AuditService.log_event(
            db=db,
            action="ROLE_CREATED",
            resource="role",
            user_id=current_user.id if current_user else None,
            resource_id=str(new_role.id),
            details={"name": new_role.name, "permission_count": len(permissions)}
        )
        return new_role

    @staticmethod
    def update_role(db: Session, role_id: int, role_in: RoleUpdate, current_user: Optional[User] = None) -> Role:
        role = RBACService.get_role_by_id(db, role_id)

        if role_in.name and role_in.name != role.name:
            if role.is_system:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Cannot rename a protected system role"
                )
            existing = db.query(Role).filter(Role.name == role_in.name).first()
            if existing:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Role with name '{role_in.name}' already exists"
                )
            role.name = role_in.name

        if role_in.description is not None:
            role.description = role_in.description

        if role_in.permission_ids is not None:
            perms = db.query(Permission).filter(Permission.id.in_(role_in.permission_ids)).all()
            role.permissions = perms

        db.commit()
        db.refresh(role)

        AuditService.log_event(
            db=db,
            action="ROLE_UPDATED",
            resource="role",
            user_id=current_user.id if current_user else None,
            resource_id=str(role.id),
            details={"name": role.name}
        )
        return role

    @staticmethod
    def delete_role(db: Session, role_id: int, current_user: Optional[User] = None) -> None:
        role = RBACService.get_role_by_id(db, role_id)
        if role.is_system:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Cannot delete protected system roles (e.g. SuperAdmin, Admin, User)"
            )

        role_name = role.name
        db.delete(role)
        db.commit()

        AuditService.log_event(
            db=db,
            action="ROLE_DELETED",
            resource="role",
            user_id=current_user.id if current_user else None,
            resource_id=str(role_id),
            details={"deleted_role": role_name}
        )

    @staticmethod
    def assign_permissions_to_role(
        db: Session,
        role_id: int,
        permission_ids: List[int],
        current_user: Optional[User] = None
    ) -> Role:
        role = RBACService.get_role_by_id(db, role_id)
        perms = db.query(Permission).filter(Permission.id.in_(permission_ids)).all()
        role.permissions = perms
        db.commit()
        db.refresh(role)

        AuditService.log_event(
            db=db,
            action="ROLE_PERMISSIONS_UPDATED",
            resource="role",
            user_id=current_user.id if current_user else None,
            resource_id=str(role.id),
            details={"role": role.name, "assigned_permissions": [p.name for p in perms]}
        )
        return role

    @staticmethod
    def get_permissions(db: Session, resource: Optional[str] = None) -> List[Permission]:
        query = db.query(Permission)
        if resource:
            query = query.filter(Permission.resource == resource)
        return query.order_by(Permission.resource, Permission.action).all()

    @staticmethod
    def create_permission(
        db: Session,
        perm_in: PermissionCreate,
        current_user: Optional[User] = None
    ) -> Permission:
        existing = db.query(Permission).filter(Permission.name == perm_in.name).first()
        if existing:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Permission '{perm_in.name}' already exists"
            )

        new_perm = Permission(
            name=perm_in.name,
            resource=perm_in.resource,
            action=perm_in.action,
            description=perm_in.description
        )
        db.add(new_perm)
        db.commit()
        db.refresh(new_perm)

        AuditService.log_event(
            db=db,
            action="PERMISSION_CREATED",
            resource="permission",
            user_id=current_user.id if current_user else None,
            resource_id=str(new_perm.id),
            details={"name": new_perm.name}
        )
        return new_perm
