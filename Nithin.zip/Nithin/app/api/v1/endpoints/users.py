from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.core.dependencies import (
    get_current_active_user,
    require_permissions
)
from app.models.user import User
from app.schemas.user import (
    UserCreate,
    UserUpdate,
    UserResponse,
    UserDetailResponse,
    UserStatusUpdate,
    UserRoleAssignRequest
)
from app.services.user_service import UserService

router = APIRouter()


@router.get(
    "/",
    response_model=List[UserResponse],
    summary="List all users with pagination and filtering",
    dependencies=[Depends(require_permissions("user:read"))]
)
def list_users(
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    role: Optional[str] = Query(None, description="Filter by role name"),
    is_active: Optional[bool] = Query(None, description="Filter by active status"),
    db: Session = Depends(get_db)
):
    """Retrieve list of users. Requires 'user:read' permission."""
    return UserService.get_users(
        db=db,
        skip=skip,
        limit=limit,
        role_name=role,
        is_active=is_active
    )


@router.post(
    "/",
    response_model=UserResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create a new user with assigned roles",
    dependencies=[Depends(require_permissions("user:create"))]
)
def create_user(
    user_in: UserCreate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Admin endpoint to create user and specify roles directly. Requires 'user:create'."""
    return UserService.create_user(db=db, user_in=user_in, current_user=current_user)


@router.get(
    "/{user_id}",
    response_model=UserDetailResponse,
    summary="Get user details by ID"
)
def get_user_by_id(
    user_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """
    Retrieve user details.
    Allows user to read their own profile, or requires 'user:read' permission for others.
    """
    if current_user.id != user_id and not current_user.has_permission("user:read"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied. Requires 'user:read' permission to view other users"
        )
    user = UserService.get_user_by_id(db=db, user_id=user_id)
    return {
        "id": user.id,
        "username": user.username,
        "email": user.email,
        "full_name": user.full_name,
        "is_active": user.is_active,
        "is_verified": user.is_verified,
        "created_at": user.created_at,
        "updated_at": user.updated_at,
        "roles": user.roles,
        "permissions": sorted(list(user.permission_names))
    }


@router.put(
    "/{user_id}",
    response_model=UserResponse,
    summary="Update user profile"
)
def update_user(
    user_id: int,
    user_in: UserUpdate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """
    Update user profile.
    Allows user to edit their own profile, or requires 'user:update' to edit others.
    """
    if current_user.id != user_id and not current_user.has_permission("user:update"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied. Requires 'user:update' permission to edit other users"
        )
    return UserService.update_user(
        db=db,
        user_id=user_id,
        user_in=user_in,
        current_user=current_user
    )


@router.put(
    "/{user_id}/status",
    response_model=UserResponse,
    summary="Activate or deactivate a user account",
    dependencies=[Depends(require_permissions("user:delete", "user:manage", match_all=False))]
)
def set_user_status(
    user_id: int,
    status_in: UserStatusUpdate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Enable or disable user account. Requires 'user:manage' or 'user:delete'."""
    return UserService.update_user_status(
        db=db,
        user_id=user_id,
        is_active=status_in.is_active,
        current_user=current_user
    )


@router.post(
    "/{user_id}/roles",
    response_model=UserResponse,
    summary="Assign roles to a user",
    dependencies=[Depends(require_permissions("role:assign"))]
)
def assign_roles(
    user_id: int,
    assignment: UserRoleAssignRequest,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Assign or replace roles for a user. Requires 'role:assign'."""
    return UserService.assign_roles_to_user(
        db=db,
        user_id=user_id,
        role_ids=assignment.role_ids,
        current_user=current_user
    )


@router.delete(
    "/{user_id}/roles/{role_id}",
    response_model=UserResponse,
    summary="Remove a specific role from a user",
    dependencies=[Depends(require_permissions("role:assign"))]
)
def remove_role(
    user_id: int,
    role_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Remove a role assignment. Requires 'role:assign'."""
    return UserService.remove_role_from_user(
        db=db,
        user_id=user_id,
        role_id=role_id,
        current_user=current_user
    )
