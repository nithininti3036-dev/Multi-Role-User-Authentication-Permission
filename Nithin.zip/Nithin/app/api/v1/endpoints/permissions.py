from typing import List, Optional
from fastapi import APIRouter, Depends, status, Query
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.core.dependencies import get_current_active_user, require_permissions
from app.models.user import User
from app.schemas.permission import PermissionCreate, PermissionResponse
from app.services.rbac_service import RBACService

router = APIRouter()


@router.get(
    "/",
    response_model=List[PermissionResponse],
    summary="List all available system permissions",
    dependencies=[Depends(require_permissions("permission:read"))]
)
def list_permissions(
    resource: Optional[str] = Query(None, description="Filter permissions by resource, e.g. 'user', 'role'"),
    db: Session = Depends(get_db)
):
    """Retrieve all system permissions. Requires 'permission:read'."""
    return RBACService.get_permissions(db=db, resource=resource)


@router.post(
    "/",
    response_model=PermissionResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create a custom permission",
    dependencies=[Depends(require_permissions("permission:create"))]
)
def create_permission(
    perm_in: PermissionCreate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Register a new granular permission in the system. Requires 'permission:create'."""
    return RBACService.create_permission(db=db, perm_in=perm_in, current_user=current_user)
