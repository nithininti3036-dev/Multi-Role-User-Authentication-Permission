from fastapi import APIRouter, Depends, status, Request
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.core.dependencies import get_current_active_user, get_client_ip
from app.core.config import settings
from app.models.user import User
from app.schemas.auth import (
    LoginRequest,
    RegisterRequest,
    Token,
    RefreshTokenRequest,
    PasswordChangeRequest,
    AuthStatusResponse
)
from app.schemas.user import UserResponse, UserDetailResponse
from app.services.auth_service import AuthService

router = APIRouter()


@router.post(
    "/login",
    response_model=Token,
    summary="Authenticate and receive JWT access & refresh tokens"
)
def login(
    credentials: LoginRequest,
    request: Request,
    db: Session = Depends(get_db)
):
    """
    Authenticate with username/email and password.
    Returns:
    - **access_token**: Short-lived bearer token (default: 60 minutes)
    - **refresh_token**: Long-lived token to obtain a fresh access token
    """
    ip = get_client_ip(request)
    user, access_token, refresh_token = AuthService.authenticate_user(
        db=db,
        credentials=credentials,
        ip_address=ip
    )
    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer",
        "expires_in": settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60
    }


@router.post(
    "/register",
    response_model=UserResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Public user registration"
)
def register(
    user_in: RegisterRequest,
    request: Request,
    db: Session = Depends(get_db)
):
    """
    Register a new user account.
    By default, new accounts receive the standard 'User' role.
    """
    ip = get_client_ip(request)
    return AuthService.register_user(db=db, user_in=user_in, ip_address=ip)


@router.post(
    "/refresh",
    response_model=Token,
    summary="Renew access token using refresh token"
)
def refresh_token(
    payload: RefreshTokenRequest,
    db: Session = Depends(get_db)
):
    """Obtain a new access and refresh token pair using an unexpired refresh token."""
    new_access, new_refresh = AuthService.refresh_access_token(
        db=db,
        refresh_token=payload.refresh_token
    )
    return {
        "access_token": new_access,
        "refresh_token": new_refresh,
        "token_type": "bearer",
        "expires_in": settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60
    }


@router.get(
    "/me",
    response_model=UserDetailResponse,
    summary="Get profile, assigned roles, and aggregated permissions for logged-in user"
)
def get_current_user_profile(
    current_user: User = Depends(get_current_active_user)
):
    """
    Retrieve current authenticated user's details, including:
    - Full profile info
    - Assigned roles
    - Full list of effective aggregated permissions
    """
    return {
        "id": current_user.id,
        "username": current_user.username,
        "email": current_user.email,
        "full_name": current_user.full_name,
        "is_active": current_user.is_active,
        "is_verified": current_user.is_verified,
        "created_at": current_user.created_at,
        "updated_at": current_user.updated_at,
        "roles": current_user.roles,
        "permissions": sorted(list(current_user.permission_names))
    }


@router.post(
    "/change-password",
    status_code=status.HTTP_200_OK,
    summary="Change password for the current authenticated user"
)
def change_password(
    payload: PasswordChangeRequest,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Change user password. Requires confirming old password."""
    AuthService.change_password(
        db=db,
        user=current_user,
        old_password=payload.old_password,
        new_password=payload.new_password
    )
    return {"message": "Password changed successfully"}
