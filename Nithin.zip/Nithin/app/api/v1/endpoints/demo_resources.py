from fastapi import APIRouter, Depends
from pydantic import BaseModel
from app.core.dependencies import (
    get_current_active_user,
    require_permissions,
    require_roles
)
from app.models.user import User

router = APIRouter()


class SampleContent(BaseModel):
    title: str
    body: str


class SampleReport(BaseModel):
    title: str
    quarter: str
    metric: float


@router.get(
    "/public",
    summary="Public endpoint accessible to anyone without authentication"
)
def public_endpoint():
    return {
        "status": "success",
        "message": "Welcome to the public API resource! No authentication required."
    }


@router.get(
    "/user-profile",
    summary="User area accessible to any authenticated active user"
)
def user_dashboard(current_user: User = Depends(get_current_active_user)):
    return {
        "status": "success",
        "message": f"Hello, {current_user.full_name or current_user.username}!",
        "roles": current_user.role_names,
        "effective_permissions": sorted(list(current_user.permission_names))
    }


@router.get(
    "/content",
    summary="Read content items",
    dependencies=[Depends(require_permissions("content:read"))]
)
def read_content():
    return {
        "status": "success",
        "items": [
            {"id": 1, "title": "Getting Started with Python & MySQL RBAC", "author": "admin"},
            {"id": 2, "title": "Security Best Practices for JWT Tokens", "author": "manager"}
        ]
    }


@router.post(
    "/content",
    summary="Create a content item",
    dependencies=[Depends(require_permissions("content:create"))]
)
def create_content(
    payload: SampleContent,
    current_user: User = Depends(get_current_active_user)
):
    return {
        "status": "success",
        "message": f"Content item '{payload.title}' created by {current_user.username}",
        "data": payload.model_dump()
    }


@router.get(
    "/reports",
    summary="View financial & analytical business reports",
    dependencies=[Depends(require_permissions("report:read"))]
)
def read_reports():
    return {
        "status": "success",
        "reports": [
            {"id": 101, "title": "Q1 Revenue Analysis", "status": "Approved"},
            {"id": 102, "title": "User Engagement Metrics", "status": "Pending Review"}
        ]
    }


@router.post(
    "/reports",
    summary="Generate a new analytical report",
    dependencies=[Depends(require_permissions("report:create"))]
)
def create_report(
    payload: SampleReport,
    current_user: User = Depends(get_current_active_user)
):
    return {
        "status": "success",
        "message": f"Report '{payload.title}' created successfully by {current_user.username}",
        "report_id": 999
    }


@router.delete(
    "/reports/{report_id}",
    summary="Delete a report",
    dependencies=[Depends(require_permissions("report:delete"))]
)
def delete_report(
    report_id: int,
    current_user: User = Depends(get_current_active_user)
):
    return {
        "status": "success",
        "message": f"Report #{report_id} permanently deleted by {current_user.username}"
    }


@router.get(
    "/admin-system-settings",
    summary="Restricted system diagnostics and configuration",
    dependencies=[Depends(require_permissions("system:admin"))]
)
def system_admin_panel(current_user: User = Depends(get_current_active_user)):
    return {
        "status": "success",
        "message": f"Access granted to restricted system panel for {current_user.username}",
        "system_status": {
            "database_engine": "MySQL / SQLAlchemy",
            "rbac_mode": "Dynamic RBAC (Role-Based Access Control)",
            "auth_mechanism": "Bearer JWT with Bcrypt Hashing"
        }
    }
