from typing import List, Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.core.dependencies import require_permissions
from app.models.audit_log import AuditLog
from app.schemas.audit_log import AuditLogResponse

router = APIRouter()


@router.get(
    "/",
    response_model=List[AuditLogResponse],
    summary="View system security and RBAC audit logs",
    dependencies=[Depends(require_permissions("audit:read"))]
)
def list_audit_logs(
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    user_id: Optional[int] = Query(None, description="Filter by user ID"),
    action: Optional[str] = Query(None, description="Filter by action name"),
    resource: Optional[str] = Query(None, description="Filter by resource name"),
    db: Session = Depends(get_db)
):
    """Retrieve security audit trails. Requires 'audit:read'."""
    query = db.query(AuditLog)
    if user_id is not None:
        query = query.filter(AuditLog.user_id == user_id)
    if action is not None:
        query = query.filter(AuditLog.action == action)
    if resource is not None:
        query = query.filter(AuditLog.resource == resource)

    return query.order_by(AuditLog.timestamp.desc()).offset(skip).limit(limit).all()
