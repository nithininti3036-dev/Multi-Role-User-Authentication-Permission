from typing import List
from fastapi import APIRouter, Depends, status, Query
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.core.dependencies import get_current_active_user, require_permissions
from app.models.user import User
from app.schemas.role import (
    RoleCreate,
    RoleUpdate,
    RoleResponse,
    RolePermissionAssignRequest
)
from app.services.rbac_service import RBACService

router = APIRouter()


@router.get(
    "/",
    response_model=List[RoleResponse],
    summary="List all roles and their assigned permissions",
    dependencies=[Depends(require_permissions("role:read"))]
)
def list_roles(
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    db: Session = Depends(get_db)
):
    """Retrieve all system and custom roles with permissions. Requires 'role:read'."""
    return RBACService.get_roles(db=db, skip=skip, limit=limit)


@router.get(
    "/{role_id}",
    response_model=RoleResponse,
    summary="Get role details by ID",
    dependencies=[Depends(require_permissions("role:read"))]
)
def get_role_by_id(
    role_id: int,
    db: Session = Depends(get_db)
):
    """Retrieve single role by ID. Requires 'role:read'."""
    return RBACService.get_role_by_id(db=db, role_id=role_id)


@router.post(
    "/",
    response_model=RoleResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create a custom role",
    dependencies=[Depends(require_permissions("role:create"))]
)
def create_role(
    role_in: RoleCreate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Create a new role with optional initial permissions. Requires 'role:create'."""
    return RBACService.create_role(db=db, role_in=role_in, current_user=current_user)


@router.put(
    "/{role_id}",
    response_model=RoleResponse,
    summary="Update role metadata or permissions",
    dependencies=[Depends(require_permissions("role:update"))]
)
def update_role(
    role_id: int,
    role_in: RoleUpdate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Update role name, description, or attached permissions. Requires 'role:update'."""
    return RBACService.update_role(
        db=db,
        role_id=role_id,
        role_in=role_in,
        current_user=current_user
    )


@router.delete(
    "/{role_id}",
    status_code=status.HTTP_200_OK,
    summary="Delete a custom role",
    dependencies=[Depends(require_permissions("role:delete"))]
)
def delete_role(
    role_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Delete a custom role. System roles cannot be deleted. Requires 'role:delete'."""
    RBACService.delete_role(db=db, role_id=role_id, current_user=current_user)
    return {"message": "Role successfully deleted"}


@router.post(
    "/{role_id}/permissions",
    response_model=RoleResponse,
    summary="Assign permissions to a role",
    dependencies=[Depends(require_permissions("role:update"))]
)
def assign_permissions_to_role(
    role_id: int,
    payload: RolePermissionAssignRequest,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Assign permissions to a role. Replaces existing permissions. Requires 'role:update'."""
    return RBACService.assign_permissions_to_role(
        db=db,
        role_id=role_id,
        permission_ids=payload.permission_ids,
        current_user=current_user
    )
