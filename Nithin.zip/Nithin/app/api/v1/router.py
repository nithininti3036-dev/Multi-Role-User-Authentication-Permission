from fastapi import APIRouter
from app.api.v1.endpoints import (
    auth,
    users,
    roles,
    permissions,
    audit,
    demo_resources
)

api_router = APIRouter()

api_router.include_router(auth.router, prefix="/auth", tags=["Authentication"])
api_router.include_router(users.router, prefix="/users", tags=["User Management"])
api_router.include_router(roles.router, prefix="/roles", tags=["Role Management (RBAC)"])
api_router.include_router(permissions.router, prefix="/permissions", tags=["Permission Catalog"])
api_router.include_router(audit.router, prefix="/audit-logs", tags=["Audit Logs"])
api_router.include_router(demo_resources.router, prefix="/resources", tags=["Protected Demo Resources"])
