from typing import List, Optional, Callable, Set
from fastapi import Depends, HTTPException, status, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.user import User
from app.core.security import decode_token

# Bearer security scheme for Swagger /docs
security_bearer = HTTPBearer(auto_error=False)


def get_client_ip(request: Request) -> str:
    """Extract client IP address handling proxies."""
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


def get_current_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security_bearer),
    db: Session = Depends(get_db)
) -> User:
    """Validate Bearer JWT access token and return current User."""
    if not credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication credentials were not provided",
            headers={"WWW-Authenticate": "Bearer"},
        )

    token = credentials.credentials
    payload = decode_token(token)

    if not payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials (invalid or expired token)",
            headers={"WWW-Authenticate": "Bearer"},
        )

    if payload.get("type") != "access":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token type (access token required)",
            headers={"WWW-Authenticate": "Bearer"},
        )

    user_id = payload.get("sub")
    if not user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token payload",
            headers={"WWW-Authenticate": "Bearer"},
        )

    user = db.query(User).filter(User.id == int(user_id)).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User associated with token no longer exists",
            headers={"WWW-Authenticate": "Bearer"},
        )

    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Account is inactive or disabled"
        )

    return user


def get_current_active_user(
    current_user: User = Depends(get_current_user)
) -> User:
    """Ensure current user is active."""
    return current_user


def require_permissions(*permissions: str, match_all: bool = True) -> Callable:
    """
    Reusable FastAPI Dependency to enforce granular permission requirements.
    Supports SuperAdmin wildcard (*:*) bypass and multi-role aggregation.
    
    Usage:
        @router.get("/reports", dependencies=[Depends(require_permissions("report:read"))])
        def get_reports(...):
    """
    def permission_checker(current_user: User = Depends(get_current_active_user)) -> User:
        # SuperAdmin always has full access
        if current_user.is_superadmin or "*:*" in current_user.permission_names:
            return current_user

        user_perms: Set[str] = current_user.permission_names

        if match_all:
            missing = [p for p in permissions if p not in user_perms]
            if missing:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"Access denied. Missing required permission(s): {', '.join(missing)}"
                )
        else:
            has_any = any(p in user_perms for p in permissions)
            if not has_any:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"Access denied. Requires at least one of: {', '.join(permissions)}"
                )

        return current_user

    return permission_checker


def require_roles(*roles: str) -> Callable:
    """
    Reusable FastAPI Dependency to enforce role-level barriers.
    
    Usage:
        @router.get("/admin", dependencies=[Depends(require_roles("Admin", "SuperAdmin"))])
        def admin_dashboard(...):
    """
    def role_checker(current_user: User = Depends(get_current_active_user)) -> User:
        if current_user.is_superadmin:
            return current_user

        has_any = any(r in current_user.role_names for r in roles)
        if not has_any:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Access denied. Required role(s): {', '.join(roles)}. Your roles: {', '.join(current_user.role_names)}"
            )

        return current_user

    return role_checker
